package com.example.fashionstore;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class FsMain extends FsBase {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_fs);
    }
}
