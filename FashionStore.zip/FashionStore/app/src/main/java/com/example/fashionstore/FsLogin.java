package com.example.fashionstore;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class FsLogin extends FsBase {

    EditText edtMobile, edtPassword;
    ConstraintLayout imgCardMobile, imgCardPassword;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_fs);

        edtMobile = findViewById(R.id.edtContact);
        edtPassword = findViewById(R.id.edtpass);

        imgCardMobile = findViewById(R.id.imgCardMobile);
        imgCardPassword = findViewById(R.id.imgCardPassword);

        edtMobile.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    imgCardMobile.setBackground(getResources().getDrawable(R.drawable.rounded60_pink_bdr));
                }else {
                    imgCardMobile.setBackground(getResources().getDrawable(R.drawable.rounded60_grey_bdr));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        edtPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    imgCardPassword.setBackground(getResources().getDrawable(R.drawable.rounded60_pink_bdr));
                }else {
                    imgCardPassword.setBackground(getResources().getDrawable(R.drawable.rounded60_grey_bdr));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }

    public void onClick(View view){
        switch (view.getId()){
            case R.id.txtLogin :
                if (TextUtils.isEmpty(edtMobile.getText().toString().trim())
                        || !isValidPhoneNumber(edtMobile.getText())) {
                    toast("Please enter valid contact");
                }else if (TextUtils.isEmpty(edtPassword.getText().toString().trim())) {
                    toast("Please enter password");
                }else {
                    startActivity(new Intent(this, FsOtp.class));
                }
                break;

            default:
                break;
        }
    }
}
